/* =========================================================
   CENTRALIZED PORTFOLIO DATA
   Update this object with your real details and URLs.
   Everything else on the page is rendered from this data.
   ========================================================= */
const PORTFOLIO = {
  name: "Naitik Singh Negi",
  initials: "nsn",
  role: "Software Developer",
  location: "Based in Your City",
  availability: "Available for select opportunities",
  email: "naitiksinghnegi.dev@gmail.com",
  tagline: "I design and build thoughtful digital experiences — from the first sketch to the final line of code.",
  heroWords: ["useful things.", "better tools.", "bold ideas.", "good software."],
  aboutLead: "I like making complicated things feel simple.",
  about: [
    "I'm a software developer who enjoys turning fuzzy ideas into clear, useful products. I care about the details — the way an interface responds, how fast a page loads, and whether a feature genuinely helps someone.",
    "My process is equal parts curiosity and craft: understand the problem, build a thoughtful solution, learn from the result, and make it better. I'm always exploring new tools and looking for the next interesting challenge."
  ],
  socials: [
    { label: "GitHub", url: "https://github.com/naitiksinghnegi", icon: "GH" },
    { label: "LinkedIn", url: "https://linkedin.com/in/yourusername", icon: "in" },
    { label: "Website", url: "https://example.com", icon: "↗" }
  ],
  technologies: [
    { name: "JavaScript", mark: "JS" },
    { name: "React", mark: "⚛" },
    { name: "Node.js", mark: "N" },
    { name: "Python", mark: "Py" },
    { name: "Git", mark: "⌘" }
  ],
  stats: [
    { value: "10+", label: "Projects explored" },
    { value: "2+", label: "Years learning & building" },
    { value: "∞", label: "Curiosity level" },
    { value: "100%", label: "Commitment to craft" }
  ],
  projects: [
    {
      number: "01",
      title: "Nexus Dashboard",
      category: "WEB APPLICATION",
      description: "A clean analytics dashboard that turns complex metrics into a useful, at-a-glance view with thoughtful data visualization.",
      technologies: ["React", "TypeScript", "Charts"],
      demoUrl: "https://example.com",
      sourceUrl: "https://github.com/yourusername/nexus-dashboard",
      accent: "#c4a8ff",
      background: "#171126",
      glow: "#6141a5",
      icon: "↗"
    },
    {
      number: "02",
      title: "DevConnect",
      category: "COMMUNITY PLATFORM",
      description: "A community experience for developers to discover collaborators, share projects, and make meaningful connections.",
      technologies: ["Node.js", "Express", "MongoDB"],
      demoUrl: "https://example.com",
      sourceUrl: "https://github.com/yourusername/devconnect",
      accent: "#8ed9d1",
      background: "#102022",
      glow: "#245f63",
      icon: "⌘"
    },
    {
      number: "03",
      title: "FocusFlow",
      category: "PRODUCTIVITY",
      description: "A distraction-light task planner built around clear priorities, calm visuals, and a simple daily workflow.",
      technologies: ["JavaScript", "CSS", "Local Storage"],
      demoUrl: "https://example.com",
      sourceUrl: "https://github.com/yourusername/focusflow",
      accent: "#ffbd9e",
      background: "#241613",
      glow: "#8c4b36",
      icon: "✳"
    },
    {
      number: "04",
      title: "GreenCart",
      category: "E-COMMERCE",
      description: "A responsive shopping concept with straightforward product discovery, clear product details, and a frictionless cart flow.",
      technologies: ["HTML", "CSS", "JavaScript"],
      demoUrl: "https://example.com",
      sourceUrl: "https://github.com/yourusername/greencart",
      accent: "#9be2b4",
      background: "#122018",
      glow: "#376a49",
      icon: "↗"
    }
  ],
  skillGroups: [
    { title: "Frontend", icon: "◈", description: "Interfaces people enjoy using.", skills: ["HTML5", "CSS3", "JavaScript", "React", "Responsive UI", "Accessibility"] },
    { title: "Backend", icon: "⌘", description: "Reliable logic behind the scenes.", skills: ["Node.js", "Express", "REST APIs", "Python", "Authentication"] },
    { title: "Data & storage", icon: "▤", description: "Data that stays organized.", skills: ["MongoDB", "PostgreSQL", "MySQL", "Firebase"] },
    { title: "Tools & workflow", icon: "⚙", description: "A smooth path from idea to ship.", skills: ["Git", "GitHub", "VS Code", "Postman", "DevTools"] },
    { title: "Design mindset", icon: "✳", description: "Clarity, craft, and usability.", skills: ["UI/UX", "Figma", "Design systems", "Prototyping"] },
    { title: "Exploring next", icon: "↗", description: "Keeping the learning loop alive.", skills: ["AI integrations", "Cloud", "Docker", "System design"] }
  ],
  journey: [
    {
      date: "2025 — NOW",
      title: "Software Developer",
      company: "Freelance & Personal Projects",
      description: "Designing and building web experiences, experimenting with product ideas, and strengthening my end-to-end development workflow."
    },
    {
      date: "2024 — 2025",
      title: "Frontend Developer",
      company: "Practice & Project Work",
      description: "Built responsive interfaces, worked with APIs, learned component-based thinking, and improved my skills in debugging and version control."
    },
    {
      date: "2022 — 2025",
      title: "Education",
      company: "Your Degree / Institution",
      description: "Add your degree, coursework, certifications, or other learning milestones here. Replace this sample entry with your actual background."
    }
  ],
  allProjectsUrl: "https://github.com/yourusername"
};

/* DOM helpers */
const byId = (id) => document.getElementById(id);
const escapeHTML = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
}[char]));
const safeURL = (value) => {
  try {
    const url = new URL(value, window.location.href);
    return ["http:", "https:", "mailto:"].includes(url.protocol) ? url.href : "#";
  } catch {
    return "#";
  }
};

function renderProfileText() {
  document.title = `${PORTFOLIO.name} — ${PORTFOLIO.role}`;
  const description = `${PORTFOLIO.name} is a ${PORTFOLIO.role.toLowerCase()} building thoughtful digital experiences and useful web applications.`;
  const metaDescription = document.querySelector('meta[name="description"]');
  if (metaDescription) metaDescription.setAttribute("content", description);

  document.querySelectorAll('[data-profile="name"]').forEach((el) => { el.textContent = PORTFOLIO.name; });
  document.querySelectorAll('[data-profile="role"]').forEach((el) => { el.textContent = PORTFOLIO.role; });
  document.querySelectorAll('[data-profile="location"]').forEach((el) => { el.textContent = PORTFOLIO.location; });
  document.querySelectorAll('[data-profile="availability"]').forEach((el) => { el.textContent = PORTFOLIO.availability; });
  document.querySelectorAll('[data-profile="tagline"]').forEach((el) => { el.textContent = PORTFOLIO.tagline; });
  document.querySelectorAll('[data-profile="aboutLead"]').forEach((el) => { el.textContent = PORTFOLIO.aboutLead; });

  const brandMark = document.querySelector(".brand-mark");
  if (brandMark) brandMark.innerHTML = `${escapeHTML(PORTFOLIO.initials)}<span>.</span>`;

  byId("aboutParagraphs").innerHTML = PORTFOLIO.about
    .map((paragraph) => `<p>${escapeHTML(paragraph)}</p>`).join("");

  byId("contactEmailLink").href = `mailto:${PORTFOLIO.email}?subject=${encodeURIComponent("Let's build something together")}`;
  byId("contactEmailText").textContent = PORTFOLIO.email;
  byId("copyright").textContent = `© ${new Date().getFullYear()} ${PORTFOLIO.name}`;
  byId("allProjectsLink").href = safeURL(PORTFOLIO.allProjectsUrl);
}

function renderSocials() {
  const markup = PORTFOLIO.socials.map((social) => `
    <a href="${escapeHTML(safeURL(social.url))}" target="_blank" rel="noopener noreferrer" aria-label="${escapeHTML(social.label)}" title="${escapeHTML(social.label)}">
      <span aria-hidden="true">${escapeHTML(social.icon)}</span>
    </a>`).join("");
  byId("heroSocials").innerHTML = markup;
  byId("footerSocials").innerHTML = markup;
}

function renderTechnologies() {
  byId("stackItems").innerHTML = PORTFOLIO.technologies.map((tech) => `
    <span class="stack-item"><span aria-hidden="true">${escapeHTML(tech.mark)}</span>${escapeHTML(tech.name)}</span>
  `).join("");
}

function renderStats() {
  byId("statsGrid").innerHTML = PORTFOLIO.stats.map((stat) => `
    <div class="stat-card reveal">
      <span class="stat-number">${escapeHTML(stat.value)}</span>
      <span class="stat-label">${escapeHTML(stat.label)}</span>
    </div>
  `).join("");
}

function renderProjects() {
  byId("projectGrid").innerHTML = PORTFOLIO.projects.map((project) => `
    <article class="project-card reveal" style="--project-bg:${escapeHTML(project.background)};--project-glow:${escapeHTML(project.glow)};--art-accent:${escapeHTML(project.accent)}">
      <div class="project-visual" aria-label="${escapeHTML(project.title)} visual preview">
        <span class="project-index">PROJECT / ${escapeHTML(project.number)}</span>
        <span class="project-category">${escapeHTML(project.category)}</span>
        <div class="project-art" aria-hidden="true">
          <div class="art-browser-bar"><i></i><i></i><i></i><span>${escapeHTML(project.title.toLowerCase().replace(/\s+/g, "-"))}.app</span></div>
          <div class="art-body">
            <div class="art-title"></div>
            <div class="art-copy"></div><div class="art-copy short"></div>
            <div class="art-blocks"><i></i><i></i><i></i></div>
          </div>
        </div>
      </div>
      <div class="project-content">
        <div class="project-title-row">
          <h3>${escapeHTML(project.title)}</h3>
          <div class="project-links">
            <a href="${escapeHTML(safeURL(project.sourceUrl))}" target="_blank" rel="noopener noreferrer" aria-label="Source code for ${escapeHTML(project.title)}">⌘</a>
            <a href="${escapeHTML(safeURL(project.demoUrl))}" target="_blank" rel="noopener noreferrer" aria-label="Live demo of ${escapeHTML(project.title)}">${escapeHTML(project.icon || "↗")}</a>
          </div>
        </div>
        <p class="project-description">${escapeHTML(project.description)}</p>
        <div class="tag-list">${project.technologies.map((technology) => `<span>${escapeHTML(technology)}</span>`).join("")}</div>
      </div>
    </article>
  `).join("");
}

function renderSkills() {
  byId("skillsGrid").innerHTML = PORTFOLIO.skillGroups.map((group) => `
    <article class="skill-card reveal">
      <div class="skill-top">
        <span class="skill-icon" aria-hidden="true">${escapeHTML(group.icon)}</span>
        <h3>${escapeHTML(group.title)}</h3>
      </div>
      <p>${escapeHTML(group.description)}</p>
      <div class="skill-tags">${group.skills.map((skill) => `<span>${escapeHTML(skill)}</span>`).join("")}</div>
    </article>
  `).join("");
}

function renderJourney() {
  byId("timeline").innerHTML = PORTFOLIO.journey.map((item) => `
    <article class="timeline-item reveal">
      <div class="timeline-date">${escapeHTML(item.date)}</div>
      <div>
        <h3 class="timeline-title">${escapeHTML(item.title)}</h3>
        <p class="timeline-company">${escapeHTML(item.company)}</p>
        <p class="timeline-description">${escapeHTML(item.description)}</p>
      </div>
    </article>
  `).join("");
}

/* Interactive terminal commands */
const terminalCommands = {
  help: () => [
    '<span class="terminal-green">Available commands</span>',
    '<span class="terminal-purple">about</span>       — a little about me',
    '<span class="terminal-purple">skills</span>      — what I work with',
    '<span class="terminal-purple">projects</span>    — selected work',
    '<span class="terminal-purple">contact</span>     — get in touch',
    '<span class="terminal-purple">location</span>    — where I am based',
    '<span class="terminal-purple">clear</span>       — clear the terminal'
  ],
  about: () => [escapeHTML(PORTFOLIO.aboutLead), escapeHTML(PORTFOLIO.tagline)],
  skills: () => [
    '<span class="terminal-green">Current toolkit</span>',
    ...PORTFOLIO.skillGroups.map((group) => `<span class="terminal-orange">${escapeHTML(group.title)}:</span> ${group.skills.map(escapeHTML).join(", ")}`)
  ],
  projects: () => [
    '<span class="terminal-green">Selected projects</span>',
    ...PORTFOLIO.projects.map((project) => `<span class="terminal-purple">${escapeHTML(project.number)} / ${escapeHTML(project.title)}</span> — ${escapeHTML(project.description)}`)
  ],
  contact: () => [
    `Email: <span class="terminal-green">${escapeHTML(PORTFOLIO.email)}</span>`,
    'Use the contact section below to start a conversation.'
  ],
  location: () => [escapeHTML(PORTFOLIO.location)],
  whoami: () => [`<span class="terminal-green">${escapeHTML(PORTFOLIO.name)}</span> — ${escapeHTML(PORTFOLIO.role)}`],
  date: () => [new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })]
};

function initTerminal() {
  const form = byId("terminalForm");
  const input = byId("terminalInput");
  const screen = byId("terminalScreen");
  const output = byId("terminalOutput");
  const history = [];
  let historyIndex = 0;

  function appendLine(content, className = "terminal-line") {
    const line = document.createElement("p");
    line.className = className;
    line.innerHTML = content;
    output.appendChild(line);
    screen.scrollTop = screen.scrollHeight;
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const raw = input.value.trim();
    if (!raw) return;
    const command = raw.toLowerCase().split(/\s+/)[0];
    history.push(raw);
    historyIndex = history.length;
    appendLine(`<span class="command-mark">alex ➜</span> ${escapeHTML(raw)}`);

    if (command === "clear") {
      output.replaceChildren();
    } else if (terminalCommands[command]) {
      terminalCommands[command]().forEach((line) => appendLine(line));
    } else {
      appendLine(`Command not found: <span class="terminal-orange">${escapeHTML(command)}</span>. Type <span class="terminal-purple">help</span> to see available commands.`);
    }
    input.value = "";
  });

  input.addEventListener("keydown", (event) => {
    if (event.key === "ArrowUp") {
      event.preventDefault();
      if (historyIndex > 0) input.value = history[--historyIndex];
    } else if (event.key === "ArrowDown") {
      event.preventDefault();
      if (historyIndex < history.length - 1) input.value = history[++historyIndex];
      else { historyIndex = history.length; input.value = ""; }
    }
  });
}

/* Mobile menu */
function initNavigation() {
  const header = document.querySelector(".site-header");
  const toggle = byId("menuToggle");
  const links = byId("navLinks");
  const navAnchors = [...links.querySelectorAll('a[href^="#"]')];

  const closeMenu = () => {
    links.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open navigation");
    document.body.classList.remove("menu-open");
  };

  toggle.addEventListener("click", () => {
    const open = toggle.getAttribute("aria-expanded") !== "true";
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
    links.classList.toggle("is-open", open);
    document.body.classList.toggle("menu-open", open);
  });
  navAnchors.forEach((anchor) => anchor.addEventListener("click", closeMenu));
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeMenu(); });
  window.addEventListener("resize", () => { if (window.innerWidth > 760) closeMenu(); });

  const onScroll = () => header.classList.toggle("is-scrolled", window.scrollY > 16);
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  if ("IntersectionObserver" in window) {
    const sectionObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        navAnchors.forEach((anchor) => {
          const active = anchor.getAttribute("href") === `#${entry.target.id}`;
          anchor.classList.toggle("active", active);
          if (active) anchor.setAttribute("aria-current", "location");
          else anchor.removeAttribute("aria-current");
        });
      });
    }, { rootMargin: "-35% 0px -55% 0px" });
    document.querySelectorAll("main section[id]").forEach((section) => sectionObserver.observe(section));
  }
}

/* Reveal on scroll, with reduced-motion fallback */
function initReveal() {
  const items = document.querySelectorAll(".reveal");
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) {
    items.forEach((item) => item.classList.add("is-visible"));
    return;
  }
  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add("is-visible");
      currentObserver.unobserve(entry.target);
    });
  }, { threshold: 0.12 });
  items.forEach((item) => observer.observe(item));
}

/* Gentle rotating hero phrase */
function initHeroRotator() {
  const target = byId("heroRotator");
  const words = PORTFOLIO.heroWords;
  if (!target || !words || words.length < 2 || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    if (target && words && words.length) target.textContent = words[0];
    return;
  }
  let index = 0;
  window.setInterval(() => {
    target.classList.add("is-changing");
    window.setTimeout(() => {
      index = (index + 1) % words.length;
      target.textContent = words[index];
      target.classList.remove("is-changing");
    }, 220);
  }, 2800);
}

/* Boot the page */
renderProfileText();
renderSocials();
renderTechnologies();
renderStats();
renderProjects();
renderSkills();
renderJourney();
initTerminal();
initNavigation();
initReveal();
initHeroRotator();
