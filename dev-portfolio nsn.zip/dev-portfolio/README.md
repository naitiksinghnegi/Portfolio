# Premium Developer Portfolio

A responsive portfolio built with plain HTML, CSS and JavaScript. No package manager or build step is required.

## Files

- `index.html` — semantic page structure and SEO metadata
- `css/style.css` — theme, responsive layout, visual effects and animation
- `js/main.js` — centralized portfolio data, page rendering, navigation and terminal commands
- `assets/favicon.svg` — editable vector favicon

## Run locally

1. Extract the folder.
2. Open `index.html` in a modern browser.

For a local development server, use VS Code's Live Server extension or run `python -m http.server 8000` from this directory and open `http://localhost:8000`.

## Personalize

Open `js/main.js` and edit the `PORTFOLIO` object near the top. Replace sample details, URLs, project descriptions, skills, stats and experience with your real information.

- `name`, `initials`, `role`, `location`, `availability`
- `email`, `tagline`, `heroWords`
- `socials`
- `projects` with real `demoUrl` and `sourceUrl` links
- `skillGroups`, `journey`, `stats`

The page is rendered from that object. Keep URLs as full `https://...` links. Update the description and Open Graph metadata in `index.html` when publishing, too.

## Interactive terminal

Try `help`, `about`, `skills`, `projects`, `contact`, `location`, `whoami`, `date`, and `clear`. The terminal also supports Up/Down arrow command history.

## Before publishing

- Replace all sample profile information and example links.
- Verify every project demo and source URL.
- Update SEO metadata and the Open Graph details in `index.html`.
- Add actual project screenshots to `assets/` if desired. The current project previews are CSS-drawn mockups, not screenshots.
- The contact button opens the visitor's email application using `mailto:`. A server or form service is needed for a contact form that submits directly on the website.
- Google Fonts is optional but requires an internet connection. System fallback fonts are provided.

## Deploy

This static site can be hosted on GitHub Pages, Netlify, Cloudflare Pages or any static web host. Upload the whole folder while preserving the relative file paths.
